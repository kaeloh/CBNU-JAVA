//1+(1+2)+(1+2+3+4)+(1+2+3+4+5)+...+(1+2+3+4+5+6+7+8+9+10)�� ����� ����ϴ� ���α׷�

public class test4_3
{
	public static void main(String args[]) 
	{	
		int sum=0;
		for(int i=1;i<=10;i++)
		{
			for(int j=1;j<=i;j++)
			{
				sum+=j;
			}
			System.out.println();
		}
		System.out.println("sum="+sum);
	}
}
